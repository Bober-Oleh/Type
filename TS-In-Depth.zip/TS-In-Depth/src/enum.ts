enum Category { JavaScript, CSS, HTML, TypeScript, Angular, React }

export { Category };