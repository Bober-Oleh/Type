export class Library {
    id: number;
    name: string;
    address: string;
};